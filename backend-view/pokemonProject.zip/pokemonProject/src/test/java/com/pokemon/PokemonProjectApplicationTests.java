package com.pokemon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PokemonProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
